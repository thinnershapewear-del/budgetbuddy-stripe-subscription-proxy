# BudgetBuddy Stripe Subscription Proxy

This proxy hides your long Stripe restricted key and exposes a short key for Lovable.

### Endpoints

- `POST /api/stripe/create-checkout-session`
  - Headers: `Authorization: Bearer <SHORT_KEY>`
  - Body: `{ "interval": "month" }` or `{ "interval": "year" }`
  - Returns: `{ "url": "<Stripe Checkout URL>" }`

### Setup

1. Go to [https://vercel.com/new](https://vercel.com/new).
2. Drag and drop this ZIP folder.
3. Add environment variables:
   - `STRIPE_KEY` = your real Stripe restricted key (`rk_test_...` or `rk_live_...`)
   - `SHORT_KEY` = a short string like `bb_live_1234`
4. Deploy.
5. Use your endpoint URL in Lovable.
