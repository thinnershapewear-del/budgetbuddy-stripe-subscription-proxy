import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_KEY, { apiVersion: "2023-10-16" });
const SHORT_KEY = process.env.SHORT_KEY || "bb_live_1234";

export default async function handler(req, res) {
  const auth = req.headers.authorization;
  if (auth !== `Bearer ${SHORT_KEY}`) {
    return res.status(403).json({ error: "Invalid key" });
  }

  try {
    if (req.method === "POST" && req.url.includes("create-checkout-session")) {
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              recurring: { interval: req.body.interval || "month" },
              unit_amount: req.body.interval === "year" ? 2499 : 299,
              product_data: { name: "BudgetBuddy Subscription" }
            },
            quantity: 1
          }
        ],
        success_url: "https://your-app.com/success",
        cancel_url: "https://your-app.com/cancel"
      });
      return res.status(200).json({ url: session.url });
    }

    return res.status(404).json({ error: "Endpoint not found" });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
}
